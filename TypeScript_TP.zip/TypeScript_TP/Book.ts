export class Book {
    title: string;
    author: string;
    pages: number;
    pagesRead: number;
    status: string;
    format: string;
    suggestedBy: string;
    price: number;
    finished: boolean;
  
    constructor(
      title: string,
      author: string,
      pages: number,
      status: string,
      format: string,
      suggestedBy: string,
      price: number
    ) {
      this.title = title;
      this.author = author;
      this.pages = pages;
      this.pagesRead = 0;
      this.status = status;
      this.format = format;
      this.suggestedBy = suggestedBy;
      this.price = price;
      this.finished = false;
    }
  
    currentlyAt(pagesRead: number) {
      this.pagesRead = pagesRead;
      if (this.pagesRead >= this.pages) {
        this.finished = true;
      }
    }
  }
  