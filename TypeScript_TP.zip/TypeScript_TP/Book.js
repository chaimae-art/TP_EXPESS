"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Book = void 0;

class Book {
    constructor(title, author, pages, status, format, suggestedBy, price) {
        this.title = title;
        this.author = author;
        this.pages = pages;
        this.pagesRead = 0; // Initialisation des pages lues à 0
        this.status = status;
        this.format = format;
        this.suggestedBy = suggestedBy;
        this.price = price;
        this.finished = false;
    }

    currentlyAt(pagesRead) {
        this.pagesRead = pagesRead;
        this.finished = this.pagesRead >= this.pages; // Utilisation d'une assignation directe
    }
}

exports.Book = Book;
