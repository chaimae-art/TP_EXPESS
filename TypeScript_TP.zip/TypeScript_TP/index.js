document.getElementById("bookForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    
    const book = {
      title: document.getElementById("title").value,
      author: document.getElementById("author").value,
      pages: parseInt(document.getElementById("pages").value),
      pagesRead: parseInt(document.getElementById("pagesRead").value) || 0,
      status: document.getElementById("status").value,
      format: document.getElementById("format").value,
      suggestedBy: document.getElementById("suggestedBy").value,
      price: parseFloat(document.getElementById("price").value),
    };
  
    await fetch("/api/books", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(book)
    });
  
    alert("Book registered successfully");
  });
  