import express from 'express';
import mysql from 'mysql2';
import { ResultSetHeader } from 'mysql2';

const app = express();
app.use(express.json());

// Connexion à la base de données MySQL
const db = mysql.createConnection({
  host: 'localhost',
  port: 8080,  // Assurez-vous que c'est bien 8080 ici
  user: 'root',
  password: 'Crvs4218',
  database: 'bookStatsDB',
});

db.connect((err) => {
  if (err) {
    console.error('Erreur de connexion à MySQL:', err);
    process.exit(1); // Arrêtez le processus si la connexion échoue
  }
  console.log('Connecté à MySQL');
});

// Route POST pour ajouter un nouveau livre
app.post('/api/livres', (req, res) => {
  const { titre, auteur, pages, statut, format, suggerePar, prix } = req.body;
  
  db.query(
    'INSERT INTO livres (titre, auteur, pages, statut, format, suggere_par, prix) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [titre, auteur, pages, statut, format, suggerePar, prix],
    (err, results) => {
      if (err) {
        console.error('Erreur lors de l\'insertion:', err);
        return res.status(500).json({ message: 'Erreur serveur lors de l\'ajout du livre.' });
      }
      
      const insertResult = results as ResultSetHeader;
      res.status(201).json({ id: insertResult.insertId });
    }
  );
});

// Route GET pour récupérer tous les livres
app.get('/api/livres', (req, res) => {
  db.query('SELECT * FROM livres', (err, results) => {
    if (err) {
      console.error('Erreur lors de la récupération des livres:', err);
      return res.status(500).json({ message: 'Erreur serveur lors de la récupération des livres.' });
    }
    res.json(results);
  });
});

// Route PUT pour mettre à jour les pages lues et le statut de terminaison d'un livre
app.put('/api/livres/:id', (req, res) => {
  const { pagesLues, pages } = req.body; // Assurez-vous que `pages` est également inclus dans `req.body`
  
  db.query(
    'UPDATE livres SET pages_lues = ?, termine = ? WHERE id = ?',
    [pagesLues, pagesLues >= pages, req.params.id],
    (err) => {
      if (err) {
        console.error('Erreur lors de la mise à jour:', err);
        return res.status(500).json({ message: 'Erreur serveur lors de la mise à jour du livre.' });
      }
      res.status(200).send({ message: 'Livre mis à jour avec succès' });
    }
  );
});

// Route DELETE pour supprimer un livre
app.delete('/api/livres/:id', (req, res) => {
  db.query('DELETE FROM livres WHERE id = ?', [req.params.id], (err) => {
    if (err) {
      console.error('Erreur lors de la suppression:', err);
      return res.status(500).json({ message: 'Erreur serveur lors de la suppression du livre.' });
    }
    res.status(204).send();
  });
});

// Démarrer le serveur
app.listen(3000, () => {
  console.log('Serveur démarré sur le port 3000');
});
