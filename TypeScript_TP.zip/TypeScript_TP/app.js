"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const mysql2_1 = __importDefault(require("mysql2"));
const path_1 = __importDefault(require("path"));

const app = (0, express_1.default)();
app.use(express_1.default.json());

// Connexion à la base de données MySQL
const db = mysql2_1.default.createConnection({
    host: 'localhost',
    port: 8080, // Utiliser le port par défaut MySQL
    user: 'root',
    password: 'Crvs4218',
    database: 'bookStatsDB'
});

db.connect((err) => {
    if (err) {
        console.error('Erreur de connexion:', err);
        throw err;
    }
    console.log('Connecté à MySQL');
});

app.post('/ajouter-livre', (req, res) => {
    const { titre, auteur, pages, pages_lues, prix, statut, format, suggere_par } = req.body;

    const sql = 'INSERT INTO livres (titre, auteur, pages, pages_lues, prix, statut, format, suggere_par) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
    const values = [titre, auteur, pages, pages_lues, prix, statut, format, suggere_par];

    db.query(sql, values, (err, result) => {
        if (err) {
            console.error('Erreur lors de l\'insertion :', err);
            return res.status(500).send('Erreur lors de l\'ajout du livre.');
        }
        res.status(201).send('Livre ajouté avec succès !');
    });
});


// Route GET pour récupérer tous les livres
app.get('/api/livres', (req, res) => {
    db.query('SELECT * FROM livres', (err, results) => {
        if (err) {
            console.error('Erreur lors de la récupération des livres:', err);
            return res.status(500).json({ message: 'Erreur serveur lors de la récupération des livres.' });
        }
        res.json(results);
    });
});

// Route PUT pour mettre à jour les pages lues et le statut de terminaison d'un livre
app.put('/api/livres/:id', (req, res) => {
    const { pagesLues, pages } = req.body;

    db.query(
        'UPDATE livres SET pages_lues = ? WHERE id = ?',
        [pagesLues, pagesLues >= pages, req.params.id],
        (err) => {
            if (err) {
                console.error('Erreur lors de la mise à jour:', err);
                return res.status(500).json({ message: 'Erreur serveur lors de la mise à jour du livre.' });
            }
            res.status(200).send({ message: 'Livre mis à jour avec succès' });
        }
    );
});

// Route DELETE pour supprimer un livre
app.delete('/supprimer-livre/:id', (req, res) => {
    db.query('DELETE FROM livres WHERE id = ?', [req.params.id], (err) => {
        if (err) {
            console.error('Erreur lors de la suppression:', err);
            return res.status(500).json({ message: 'Erreur serveur lors de la suppression du livre.' });
        }
        res.status(204).send();
    });
});

// Route par défaut pour servir index.html
app.get('/', (req, res) => {
    res.sendFile(path_1.default.join(__dirname, 'index.html'));
});

// Démarrer le serveur
app.listen(3002, () => {
    console.log('Serveur démarré sur le port 3002');
});
