/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [], // Assurez-vous que les chemins sont corrects
  theme: {
    extend: {},
  },
  plugins: [],
};

