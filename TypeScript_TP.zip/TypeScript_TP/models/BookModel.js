// models/BookModel.js
const mongoose = require('mongoose');

const bookSchema = new mongoose.Schema({
  title: { type: String, required: true },
  author: { type: String, required: true },
  pages: { type: Number, required: true },
  status: {
    type: String,
    enum: ['Read', 'Re-read', 'DNF', 'Currently reading', 'Returned Unread', 'Want to read'],
    required: true
  },
  price: { type: Number, required: true },
  pagesRead: { type: Number, default: 0 },
  format: {
    type: String,
    enum: ['Print', 'PDF', 'Ebook', 'AudioBook'],
    required: true
  },
  suggestedBy: { type: String, required: false },
  finished: { type: Boolean, default: false }
});

// Export the Book model
module.exports = mongoose.model('Book', bookSchema);
