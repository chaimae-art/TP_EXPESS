const express = require('express');
const app = express();

app.use(express.json()); 

const PORT = 5000; 
app.listen(PORT, () => {
    console.log(`Serveur démarré sur http://localhost:${PORT}`);
});


let items = []; // Tableau pour stocker les éléments

// Point d'accès POST pour ajouter un nouvel élément
app.post('/items', (req, res) => {
    const newItem = req.body; // Récupérer l'élément du corps de la requête
    items.push(newItem); // L'ajouter au tableau
    res.status(201).send(newItem); // Envoyer l'élément ajouté comme réponse
});


// Point d'accès GET pour récupérer tous les éléments
app.get('/items', (req, res) => {
    res.send(items); // Envoyer tous les éléments comme réponse
});


// Point d'accès GET pour obtenir un élément spécifique
app.get('/items/:id', (req, res) => {
    const itemId = req.params.id; // Récupérer l'ID depuis l'URL
    const item = items[itemId]; // Récupérer l'élément du tableau

    if (item) {
        res.send(item); // Envoyer l'élément comme réponse
    } else {
        res.status(404).send('Élément non trouvé'); // Si l'élément n'existe pas
    }
});



// Point d'accès PUT pour mettre à jour un élément spécifique
app.put('/items/:id', (req, res) => {
    const itemId = req.params.id; // Récupérer l'ID depuis l'URL
    const updatedItem = req.body; // Récupérer l'élément mis à jour depuis le corps de la requête

    if (items[itemId]) {
        items[itemId] = updatedItem; // Mettre à jour l'élément
        res.send(updatedItem); // Envoyer l'élément mis à jour comme réponse
    } else {
        res.status(404).send('Élément non trouvé'); // Si l'élément n'existe pas
    }
});



// Point d'accès DELETE pour supprimer un élément spécifique
app.delete('/items/:id', (req, res) => {
    const itemId = req.params.id; // Récupérer l'ID depuis l'URL

    if (items[itemId]) {
        items.splice(itemId, 1); // Supprimer l'élément du tableau
        res.send('Élément supprimé'); // Envoyer une confirmation de la suppression
    } else {
        res.status(404).send('Élément non trouvé'); // Si l'élément n'existe pas
    }
});


